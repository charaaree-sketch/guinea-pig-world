# 몽글몽글 기니피그 월드 — Vercel/Supabase 연결 수정본

이 버전은 정적 Vercel 사이트에서 Supabase 환경변수를 브라우저 코드가 직접 읽지 못하던 문제를 수정했습니다.

## Vercel 환경변수
Vercel 프로젝트 Settings → Environment Variables에 아래 두 개를 설정하세요.

- `SUPABASE_URL`
- `SUPABASE_PUBLISHABLE_KEY`

Publishable key는 `sb_publishable_...` 형식이며 브라우저 앱에서 사용하도록 설계된 키입니다. `sb_secret_...` 또는 `service_role` 키는 절대 넣지 마세요.

`api/config.js`가 Vercel 서버에서 환경변수를 읽어 브라우저에 publishable key만 전달합니다.

## 배포
GitHub 저장소의 기존 `index.html`, `app.js`, `styles.css`를 이 폴더의 파일로 교체하고 `api/config.js`도 함께 올린 뒤 Vercel에서 Redeploy하세요.
