const CFG={url:localStorage.getItem('GP_SUPABASE_URL')||'',key:localStorage.getItem('GP_SUPABASE_ANON_KEY')||''};
let sb=null,currentUser=null;
let configError='';

async function initSupabase(){
  try{
    // Vercel serverless config: reads the publishable key from Vercel Environment Variables.
    // The publishable key is safe for browser apps; never use a secret/service-role key here.
    if(window.supabase && (!CFG.url || !CFG.key)){
      const r=await fetch('/api/config',{cache:'no-store'});
      if(r.ok){
        const c=await r.json();
        if(c.url && c.key){
          CFG.url=c.url.trim(); CFG.key=c.key.trim();
          localStorage.setItem('GP_SUPABASE_URL',CFG.url);
          localStorage.setItem('GP_SUPABASE_ANON_KEY',CFG.key);
        }
      }
    }
    if(!window.supabase){configError='Supabase 라이브러리를 불러오지 못했어.';return false}
    if(!CFG.url || !CFG.key){configError='Vercel 환경변수(SUPABASE_URL / SUPABASE_PUBLISHABLE_KEY)가 연결되지 않았어.';return false}
    sb=window.supabase.createClient(CFG.url,CFG.key,{auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:true}});
    // A lightweight request validates URL + key before showing auth UI.
    const {error}=await sb.auth.getSession();
    if(error){configError=error.message||'Supabase 연결에 실패했어.';sb=null;return false}
    return true;
  }catch(e){configError=e?.message||'Supabase 연결 중 오류가 발생했어.';sb=null;return false}
}
const page=document.querySelector('#page'),statusEl=document.querySelector('#onlineStatus');
const state={page:'home',selected:null,pigs:[],decor:JSON.parse(localStorage.getItem('gp_decor')||'[]'),nick:localStorage.getItem('gp_nick')||'',players:[],channel:null};
const breeds=[['몽실이','크림&브라운','pig-cream'],['초코','초코&화이트','pig-brown'],['설이','화이트','pig-white'],['단추','그레이','pig-gray'],['호두','브라운','pig-brown'],['구름','블랙&화이트','pig-black'],['라떼','오렌지','pig-orange'],['솜이','아이보리','pig-cream']];
const decors=[['🌿','잔디'],['🪵','나무터널'],['🏠','작은집'],['🥕','당근밭'],['🌷','꽃화분'],['🛏️','폭신침대'],['🪨','돌장식'],['🧸','인형'],['🥣','먹이그릇'],['💧','물그릇'],['🎡','미니휠'],['🌳','통나무']];
function saveLocal(){localStorage.setItem('gp_decor',JSON.stringify(state.decor));localStorage.setItem('gp_nick',state.nick)}
function pigHTML(p,small=false){return `<div class="gp ${p?.color||'pig-cream'}" style="transform:scale(${small?.65:1})"><div class="body"><i class="patch"></i><div class="head"><i class="ear l"></i><i class="ear r"></i><i class="eye"></i><i class="nose"></i></div><i class="leg l"></i><i class="leg r"></i></div></div>`}
function nav(){document.querySelectorAll('nav button').forEach(b=>b.classList.toggle('active',b.dataset.page===state.page))}
function render(){nav();({home,adopt,cage,plaza,walk}[state.page]||home)();statusEl.textContent=sb&&currentUser?`온라인 · ${state.nick||currentUser.email}`:sb?'서버 연결됨 · 로그인 필요':`연결 안 됨${configError?' · '+configError:''}`}
function shell(title,desc,body){page.innerHTML=`<div class="wrap"><section class="hero"><h1>${title}</h1><p>${desc}</p>${body}</section></div>`}
function home(){const p=state.selected||state.pigs[0];shell('🐹 몽글몽글 기니피그 월드','돈이나 코인 없이 기니피그를 돌보고, 케이지를 꾸미고, 친구들을 만나는 게임이야.',`<div class="actions"><button class="primary" onclick="go('adopt')">기니피그 입양하기</button><button class="soft" onclick="go('cage')">케이지 꾸미기</button><button class="soft" onclick="go('plaza')">광장 가기</button></div><div class="section"><h2>내 기니피그 ${state.pigs.length}마리</h2><div class="grid">${state.pigs.length?state.pigs.map((x,i)=>`<div class="gp-card ${p===x?'selected':''}" onclick="selectPig(${i})">${pigHTML(x)}<div class="meta"><span class="name">${esc(x.name)}</span><span class="tag">${esc(x.type)}</span></div><div class="small">${x.hunger<30?'배고파요':'기분 좋아요'} 🐹</div></div>`).join(''):'<div class="panel empty">무료로 기니피그를 입양해보자 🐹</div>'}</div></div>`)}
function adopt(){shell('🐹 기니피그 입양','모두 무료야. 마음에 드는 아이를 골라 이름을 지어줘!',`<div class="grid">${breeds.map((b,i)=>`<div class="gp-card">${pigHTML({color:b[2]})}<div class="meta"><span class="name">${b[0]}</span><span class="tag">${b[1]}</span></div><button class="primary" style="width:100%;margin-top:9px" onclick="adoptPig(${i})">무료로 입양</button></div>`).join('')}</div>`)}
async function adoptPig(i){if(!requireLogin())return;const b=breeds[i],name=prompt('기니피그 이름을 지어줘!',b[0]);if(!name?.trim())return;const p={id:crypto.randomUUID(),owner_id:currentUser.id,name:name.trim(),type:b[1],color:b[2],hunger:100,outfit:'',accessory:'',x:35,y:58};const {error}=await sb.from('guinea_pigs').insert(p);if(error)return alert('입양 저장에 실패했어: '+error.message);state.pigs.push(p);state.selected=p;go('home')}
function selectPig(i){state.selected=state.pigs[i];render()}
function cage(){const p=state.selected||state.pigs[0];shell('🪴 내 케이지','오브젝트를 눌러 케이지에 놓아보자. 다시 누르면 사라져.',p?`<div class="cage">${state.decor.map((d,i)=>`<button class="decor" style="left:${d.x}%;top:${d.y}%" onclick="removeDecor(${i})">${d.e}</button>`).join('')}${pigHTML(p)}</div><div class="cage-controls">${decors.map(d=>`<button class="decor-card" onclick="addDecor('${d[0]}','${d[1]}')"><div class="emoji">${d[0]}</div><div class="small">${d[1]}</div></button>`).join('')}</div>`:'<div class="empty">먼저 기니피그를 입양해줘!</div>')}
function addDecor(e,n){state.decor.push({e,n,x:10+Math.random()*78,y:30+Math.random()*55});saveLocal();render()}function removeDecor(i){state.decor.splice(i,1);saveLocal();render()}
function playerHTML(x){return `<div class="player" style="left:${x.x}%;top:${x.y}%"><div class="bubble">${esc(x.msg||'안녕! 🐹')}</div><div class="mini"></div><div style="text-align:center;font-size:11px">${esc(x.name)}</div></div>`}
function plaza(){shell('🌳 몽글 광장',sb&&currentUser?'실시간으로 접속한 친구들이 보여!':'로그인하고 서버를 연결하면 실제 유저를 만날 수 있어.',`<div class="plaza">${state.players.map(playerHTML).join('')}</div><div class="chat"><input id="chatInput" placeholder="광장에 한마디 남기기" maxlength="80"><button class="primary" onclick="sendChat()">보내기</button></div>`);if(sb&&currentUser)subscribePresence('plaza')}
function sendChat(){const input=document.querySelector('#chatInput');if(!input?.value.trim()||!state.channel)return;state.channel.send({type:'broadcast',event:'chat',payload:{name:state.nick||'친구',msg:input.value.trim()}});input.value=''}
function walk(){const p=state.selected||state.pigs[0];shell('🌿 산책','산책 중에는 실제로 접속한 친구들의 기니피그가 보여.',`<div class="actions"><button class="primary" onclick="startWalk()">산책 시작</button><button class="soft" onclick="stopWalk()">산책 끝내기</button></div><div class="walkfield">${state.players.map(playerHTML).join('')}${p?`<div class="player" style="left:45%;top:65%">${pigHTML(p,true)}<div style="text-align:center;font-size:11px">${esc(state.nick)}</div></div>`:''}</div>`)}
let timer=null;function startWalk(){if(!requireLogin())return;if(sb&&currentUser)subscribePresence('walk');else return;clearInterval(timer);timer=setInterval(()=>{if(state.page!=='walk')return;state.players.forEach(x=>{x.x=Math.max(5,Math.min(88,x.x+(Math.random()*12-6)));x.y=Math.max(25,Math.min(72,x.y+(Math.random()*10-5)))});render();broadcastPresence()},1800)}function stopWalk(){clearInterval(timer);timer=null}
async function subscribePresence(room){if(!sb||!currentUser)return;if(state.channel){await state.channel.unsubscribe();state.channel=null}const key=currentUser.id;state.channel=sb.channel('gp-'+room,{config:{presence:{key}}});state.channel.on('presence',{event:'sync'},()=>{const all=state.channel.presenceState();state.players=Object.values(all).flat().filter(x=>x.user_id!==currentUser.id);render()}).on('broadcast',{event:'chat'},p=>{if(state.page==='plaza'){state.players.push({id:crypto.randomUUID(),name:p.payload.name,pig:'',x:10+Math.random()*75,y:30+Math.random()*40,msg:p.payload.msg});render()}}).subscribe(async s=>{if(s==='SUBSCRIBED')broadcastPresence()})}
async function broadcastPresence(){if(!state.channel)return;await state.channel.track({user_id:currentUser.id,name:state.nick||'친구',pig:(state.selected||{}).name||'기니피그',x:20+Math.random()*60,y:35+Math.random()*35,msg:'안녕! 🐹'})}
async function loadPigs(){if(!sb||!currentUser)return;const {data,error}=await sb.from('guinea_pigs').select('*').eq('owner_id',currentUser.id).order('created_at',{ascending:true});if(error){console.warn(error);return}state.pigs=data||[];state.selected=state.pigs[0]||null;render()}
function requireLogin(){if(!currentUser){showAuth('login');return false}return true}
function showAuth(mode='login'){const old=document.querySelector('.auth-backdrop');if(old)old.remove();const d=document.createElement('div');d.className='auth-backdrop';d.innerHTML=`<div class="auth-box"><h2>🐹 ${mode==='login'?'로그인':'회원가입'}</h2><p class="small">내 기니피그와 케이지를 계정에 안전하게 저장해!</p><div class="auth-tabs"><button class="${mode==='login'?'on':''}" onclick="showAuth('login')">로그인</button><button class="${mode==='signup'?'on':''}" onclick="showAuth('signup')">회원가입</button></div>${mode==='signup'?'<input id="authNick" placeholder="닉네임" maxlength="16">':''}<input id="authEmail" type="email" placeholder="이메일"><input id="authPw" type="password" placeholder="비밀번호 (6자 이상)"><button class="primary" style="width:100%;margin-top:8px" onclick="submitAuth('${mode}')">${mode==='login'?'로그인':'회원가입'}</button><div id="authMsg" class="auth-msg"></div><button class="soft" style="width:100%" onclick="this.closest('.auth-backdrop').remove()">닫기</button></div>`;document.body.appendChild(d)}
async function submitAuth(mode){if(!sb)return alert('먼저 Supabase 주소와 키를 설정해야 해.');const email=document.querySelector('#authEmail').value.trim(),password=document.querySelector('#authPw').value;const msg=document.querySelector('#authMsg');if(!email||password.length<6){msg.textContent='이메일과 6자 이상 비밀번호를 입력해줘.';return}if(mode==='signup'){const nick=document.querySelector('#authNick').value.trim()||'기니친구';const {data,error}=await sb.auth.signUp({email,password,options:{data:{nickname:nick},emailRedirectTo:location.href}});if(error){msg.textContent=error.message;return}state.nick=nick;saveLocal();msg.textContent=data.session?'가입 완료!':'가입 완료! 이메일 인증 후 로그인해줘.';if(data.session){await finishLogin(data.user);document.querySelector('.auth-backdrop')?.remove()}}else{const {data,error}=await sb.auth.signInWithPassword({email,password});if(error){msg.textContent=error.message;return}await finishLogin(data.user);document.querySelector('.auth-backdrop')?.remove()}}
async function finishLogin(user){currentUser=user;state.nick=state.nick||user.user_metadata?.nickname||user.email?.split('@')[0]||'친구';saveLocal();await loadPigs();if(!state.pigs.length){const p={id:crypto.randomUUID(),owner_id:user.id,name:'몽실이',type:'크림&브라운',color:'pig-cream',hunger:100,outfit:'',accessory:''};const {error}=await sb.from('guinea_pigs').insert(p);if(!error){state.pigs=[p];state.selected=p}}render()}
async function logout(){if(sb)await sb.auth.signOut();currentUser=null;state.pigs=[];state.selected=null;state.players=[];state.channel?.unsubscribe();state.channel=null;render();showAuth('login')}
async function configure(){
  const url=prompt('Supabase Project URL을 입력해줘',CFG.url); if(!url)return;
  const key=prompt('Supabase Publishable Key(sb_publishable_...) 또는 Legacy anon key를 입력해줘',CFG.key); if(!key)return;
  const cleanUrl=url.trim().replace(/\/$/,''); const cleanKey=key.trim();
  if(!/^https:\/\/[^\s]+\.supabase\.co$/.test(cleanUrl)){alert('Supabase Project URL 형식이 올바르지 않아.');return}
  if(!(cleanKey.startsWith('sb_publishable_')||cleanKey.startsWith('eyJ'))){alert('브라우저에서는 sb_publishable_... 또는 기존 anon 키만 사용할 수 있어.');return}
  localStorage.setItem('GP_SUPABASE_URL',cleanUrl);localStorage.setItem('GP_SUPABASE_ANON_KEY',cleanKey);location.reload();
}
function headerUser(){let u=document.querySelector('.userbar');if(u)u.remove();u=document.createElement('div');u.className='userbar';u.innerHTML=currentUser?`<span>👤 ${esc(state.nick)}</span><button onclick="logout()">로그아웃</button>`:`<button onclick="showAuth('login')">로그인</button><button onclick="showAuth('signup')">회원가입</button>${!sb?'<button onclick="configure()">서버 연결</button>':''}`;document.querySelector('.topbar').appendChild(u)}
function go(x){state.page=x;render();headerUser();if(x==='plaza'&&sb&&currentUser)subscribePresence('plaza')}
function esc(v){return String(v??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]))}
document.querySelectorAll('nav button').forEach(b=>b.onclick=()=>go(b.dataset.page));window.go=go;window.adoptPig=adoptPig;window.selectPig=selectPig;window.addDecor=addDecor;window.removeDecor=removeDecor;window.sendChat=sendChat;window.startWalk=startWalk;window.stopWalk=stopWalk;window.showAuth=showAuth;window.submitAuth=submitAuth;window.logout=logout;window.configure=configure;
(async()=>{
  await initSupabase();
  headerUser();
  if(sb){
    const {data}=await sb.auth.getSession();
    if(data.session) await finishLogin(data.session.user);
    sb.auth.onAuthStateChange((_e,session)=>{
      if(session && !currentUser) finishLogin(session.user);
      if(!session && currentUser){currentUser=null;state.pigs=[];state.selected=null;render();headerUser();}
    });
  }
  render();
  headerUser();
  if(!currentUser && !sb && !localStorage.getItem('GP_SUPABASE_URL')) showAuth('login');
})();
